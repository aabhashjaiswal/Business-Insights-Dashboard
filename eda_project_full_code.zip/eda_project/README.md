# Data Preprocessing & EDA Project

## Objective
End-to-end pipeline for data cleaning, feature engineering, and exploratory data analysis. Generates processed datasets and figures automatically.

## How to Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python main.py
```
Outputs:
- Clean data → `data/processed/clean.csv` and `clean.parquet`
- Figures → `reports/figures/`

## Notebook
Open `notebooks/01_data_audit_eda.ipynb` and **Run All** to reproduce the basic workflow.

## Project Structure
```
eda_project/
├─ data/
│  ├─ raw/            # original (contains customers.csv)
│  └─ processed/      # cleaned data (auto-generated)
├─ notebooks/
│  └─ 01_data_audit_eda.ipynb
├─ reports/
│  └─ figures/        # charts (auto-generated)
├─ src/
│  ├─ data_preprocessing.py
│  └─ eda_utils.py
├─ main.py
├─ requirements.txt
└─ README.md
```
