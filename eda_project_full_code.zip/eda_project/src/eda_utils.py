from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PROC = Path(__file__).resolve().parents[1] / "data" / "processed"
FIGS = Path(__file__).resolve().parents[1] / "reports" / "figures"
FIGS.mkdir(parents=True, exist_ok=True)

def load_clean(filename: str = "clean.csv") -> pd.DataFrame:
    return pd.read_csv(PROC / filename)

def plot_hist(df: pd.DataFrame, col: str):
    plt.figure()
    df[col].hist(bins=20)
    plt.title(f"Distribution of {col}")
    plt.xlabel(col); plt.ylabel("Count")
    plt.tight_layout()
    path = FIGS / f"hist_{col}.png"
    plt.savefig(path, dpi=200)
    plt.close()
    return path

def plot_scatter(df: pd.DataFrame, x: str, y: str):
    plt.figure()
    plt.scatter(df[x], df[y], alpha=0.6)
    plt.title(f"{x} vs {y}")
    plt.xlabel(x); plt.ylabel(y)
    plt.tight_layout()
    path = FIGS / f"scatter_{x}_vs_{y}.png"
    plt.savefig(path, dpi=200)
    plt.close()
    return path

def plot_corr(df: pd.DataFrame):
    corr = df.select_dtypes(include="number").corr()
    plt.figure()
    plt.imshow(corr, aspect="auto")
    plt.title("Correlation Heatmap")
    plt.colorbar()
    plt.tight_layout()
    path = FIGS / "corr_heatmap.png"
    plt.savefig(path, dpi=200)
    plt.close()
    return path
