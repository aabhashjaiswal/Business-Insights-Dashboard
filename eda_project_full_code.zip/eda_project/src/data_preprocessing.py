from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

RAW = Path(__file__).resolve().parents[1] / "data" / "raw"
PROC = Path(__file__).resolve().parents[1] / "data" / "processed"
FIGS = Path(__file__).resolve().parents[1] / "reports" / "figures"

PROC.mkdir(parents=True, exist_ok=True)
FIGS.mkdir(parents=True, exist_ok=True)

def load_data(filename: str = "customers.csv") -> pd.DataFrame:
    df = pd.read_csv(RAW / filename)
    return df

def integrity_report(df: pd.DataFrame) -> dict:
    return {
        "rows": len(df),
        "cols": len(df.columns),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "missing_per_col": df.isna().sum().to_dict(),
        "duplicates": int(df.duplicated().sum())
    }

def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    num_cols = df.select_dtypes(include=np.number).columns
    cat_cols = df.select_dtypes(exclude=np.number).columns
    df[num_cols] = df[num_cols].fillna(df[num_cols].median())
    for c in cat_cols:
        if df[c].isna().any():
            df[c] = df[c].fillna(df[c].mode().iloc[0])
    return df

def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    return df.drop_duplicates()

def cap_outliers_iqr(df: pd.DataFrame, cols=None) -> pd.DataFrame:
    if cols is None:
        cols = df.select_dtypes(include=np.number).columns
    for c in cols:
        q1, q3 = df[c].quantile([0.25, 0.75])
        iqr = q3 - q1
        lo, hi = q1 - 1.5*iqr, q3 + 1.5*iqr
        df[c] = df[c].clip(lo, hi)
    return df

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df["spend_per_purchase"] = (df["spend"] / df["purchases"].replace(0, 1)).round(2)
    df["high_income"] = (df["monthly_income"] > df["monthly_income"].median()).astype(int)
    df = pd.get_dummies(df, columns=["gender","contract_type"], drop_first=True)
    return df

def scale_numeric(df: pd.DataFrame, exclude=("customer_id",)) -> pd.DataFrame:
    scaler = StandardScaler()
    num_cols = [c for c in df.select_dtypes(include="number").columns if c not in exclude]
    df[num_cols] = scaler.fit_transform(df[num_cols])
    return df

def save_outputs(df_clean: pd.DataFrame):
    df_clean.to_parquet(PROC / "clean.parquet", index=False)
    df_clean.to_csv(PROC / "clean.csv", index=False)

def run_pipeline():
    df = load_data()
    report_before = integrity_report(df)
    df = handle_missing(df)
    df = remove_duplicates(df)
    df = cap_outliers_iqr(df)
    df = engineer_features(df)
    df = scale_numeric(df)
    save_outputs(df)
    report_after = integrity_report(df)
    return report_before, report_after

if __name__ == "__main__":
    before, after = run_pipeline()
    print("Integrity (before):", before)
    print("Integrity (after):", after)
