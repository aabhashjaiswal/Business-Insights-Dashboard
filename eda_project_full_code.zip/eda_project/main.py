from src.data_preprocessing import run_pipeline
from src.eda_utils import load_clean, plot_hist, plot_scatter, plot_corr

def main():
    before, after = run_pipeline()
    print("Pipeline completed.")
    print("Before:", before)
    print("After:", after)

    df = load_clean()
    try:
        plot_hist(df, "age")
    except Exception:
        pass
    x_col = "tenure_months"
    y_col = "spend"
    if x_col in df.columns and y_col in df.columns:
        plot_scatter(df, x_col, y_col)
    plot_corr(df)

if __name__ == "__main__":
    main()
